package Integrador2;

public interface List {

    void add(int a);
    int size();
    void remove();
    int get(int index);

}
