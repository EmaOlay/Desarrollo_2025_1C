package Integrador2;

public interface Stack {
    void add(Dupla d);
    void remove();
    Dupla getTop();
    boolean isEmpty();
}